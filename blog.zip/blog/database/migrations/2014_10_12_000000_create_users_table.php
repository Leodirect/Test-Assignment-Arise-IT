<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('data', function (Blueprint $table) {
            $table->integer('date')->nullable();
            $table->float('SMALL LoBM LoOP',8,4)->nullable();
            $table->float('ME1 BM1 OP2',8,4)->nullable();
            $table->float('ME1 BM1 OP3',8,4)->nullable();
            $table->float('SMALL LoBM HiOP',8,4)->nullable();
            $table->float('ME1 BM2 OP1',8,4)->nullable();
            $table->float('ME1 BM2 OP2',8,4)->nullable();
            $table->float('ME1 BM2 OP3',8,4)->nullable();
            $table->float('ME1 BM2 OP4',8,4)->nullable();
            $table->float('ME1 BM3 OP1',8,4)->nullable();
            $table->float('ME1 BM3 OP2',8,4)->nullable();
            $table->float('ME1 BM3 OP3',8,4)->nullable();
            $table->float('ME1 BM3 OP4',8,4)->nullable();
            $table->float('SMALL HiBM LoOP',8,4)->nullable();
            $table->float('ME1 BM4 OP2',8,4)->nullable();
            $table->float('ME1 BM4 OP3',8,4)->nullable();
            $table->float('SMALL HiBM HiOP',8,4)->nullable();
            $table->float('BIG LoBM LoOP',8,4)->nullable();
            $table->float('ME2 BM1 OP2',8,4)->nullable();
            $table->float('ME2 BM1 OP3',8,4)->nullable();
            $table->float('BIG LoBM HiOP',8,4)->nullable();
            $table->float('ME2 BM2 OP1',8,4)->nullable();
            $table->float('ME2 BM2 OP2',8,4)->nullable();
            $table->float('ME2 BM2 OP3',8,4)->nullable();
            $table->float('ME2 BM2 OP4',8,4)->nullable();
            $table->float('ME2 BM3 OP1',8,4)->nullable();
            $table->float('ME2 BM3 OP2',8,4)->nullable();
            $table->float('ME2 BM3 OP3',8,4)->nullable();
            $table->float('ME2 BM3 OP4',8,4)->nullable();
            $table->float('BIG HiBM LoOP',8,4)->nullable();
            $table->float('ME2 BM4 OP2',8,4)->nullable();
            $table->float('ME2 BM4 OP3',8,4)->nullable();
            $table->float('BIG HiBM HiOP',8,4)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
