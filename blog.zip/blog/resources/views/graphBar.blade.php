@extends('Layout')

@section ('contenu')
    <div id="ca_graph"></div>
    <?=$lava->render('ScatterChart','Stocks','ca_graph');?>
@endsection