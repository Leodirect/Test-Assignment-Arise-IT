<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">

    <link rel="stylesheet" href="{{asset('css/header.css')}}">
    <link rel="stylesheet" href="{{asset('css/footer.css')}}">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="https://use.fontawesome.com/d1341f9b7a.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link crossorigin="anonymous" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css">
    <title>Test Assignment</title>
</head>

<body>
<header>

    <h1>
        Test assignment
    </h1>

</header>

<nav>

    <ul>
        <li><a href="/">Accueil</a></li>
        <li><a href="/csv">Import .csv</a></li>
        <li><a href="/graph">Graphics</a></li>

    </ul>
    <div class="hide">
        <i class="fa fa-bars" aria-hidden="true"></i> Menu
    </div>
</nav>
<script type="text/javascript">
    $('.hide').on('click',function(){
        $('nav ul').toggleClass('show');
    });
</script>


<main>

    @yield('contenu')

<footer class="footer">
    <div>

    </div>

    <div class="middle">
            <a class="btnn" href="mailto:leo.olivier@viacesi.fr">
                <i class="fas fa-at"></i>
            </a>
    </div>


</footer>

</body>
</html>