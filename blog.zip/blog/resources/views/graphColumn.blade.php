@extends('Layout')

@section ('contenu')
    <div id="ca_graph"></div>
    <?=$lava->render('ColumnChart','Stocks','ca_graph');?>
@endsection