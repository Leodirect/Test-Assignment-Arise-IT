<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Khill\Lavacharts\Lavacharts;
use App\data;
use Illuminate\Support\Facades\DB;

class GraphDuoController extends Controller
{

    public function index(Request $request){
        $table = $request["data"];
        $secondTable=$request["secondData"];
        $startRange = $request["startRange"];
        $endRange = $request["endRange"];
        $lava = new Lavacharts();
        $date = DB::table('data')->select('date')->get();
        $date = json_decode($date, true);
        $small = DB::table('data')->select($table)->get();
        $small = json_decode($small, true);
        $graph2 = DB::table('data')->select($secondTable)->get();
        $graph2 = json_decode($graph2, true);

        $data = $lava->DataTable();

        $data->addNumberColumn('date')
            ->addNumberColumn($table)
            ->addNumberColumn($secondTable);


// Random Data For Example
        for ($a = $startRange; $a < $endRange; $a++) {
            $tempo = $date[$a]["date"];

            $tempoSmall = $small[$a][$table];
            $tempGraph2= $graph2[$a][$secondTable];

            $rowData = [
                $tempo, $tempoSmall,$tempGraph2
            ];
            $data->addRow($rowData);
        }
        $lava->LineChart('Stocks', $data, [
            'title' => $table,
            'animation' => [
                'startup' => true,
                'easing' => 'inAndOut'
            ],
            'colors' => ['blue', '#F4C1D8']
        ]);

        return view("graphData",["lava"=>$lava]);

    }
}