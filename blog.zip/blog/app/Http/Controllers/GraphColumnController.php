<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Khill\Lavacharts\Lavacharts;
use App\data;
use Illuminate\Support\Facades\DB;

class GraphColumnController extends Controller
{

    public function index(Request $request){
        $table = $request["data"];
        $startRange = $request["startRange"];
        $endRange = $request["endRange"];
        $lava = new Lavacharts();
        $date = DB::table('data')->select('date')->get();
        $date = json_decode($date, true);
        $small = DB::table('data')->select($table)->get();
        $small = json_decode($small, true);

        $data = $lava->DataTable();

        $data->addNumberColumn('date')
            ->addNumberColumn($table);

        for ($a = $startRange; $a < $endRange; $a++) {
            $tempo = $date[$a]["date"];

            $tempoSmall = $small[$a][$table];

            $rowData = [
                $tempo, $tempoSmall
            ];
            $data->addRow($rowData);
        }
        $lava->ColumnChart('Stocks', $data, [
            'title' => $table,
            'animation' => [
                'startup' => true,
                'easing' => 'inAndOut'
            ],
            'colors' => ['blue', '#F4C1D8']
        ]);
        return view("graphColumn",["lava"=>$lava]);

    }
}

