<?php $__env->startSection('contenu'); ?>
    <div id="ca_graph"></div>
    <?=$lava->render('ScatterChart','Stocks','ca_graph');?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>