<?php $__env->startSection('contenu'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/graph.css')); ?>">
<head>
    <title>Test graph</title>
</head>
<body>

    <form action="/graph2">
        <p>Line Graphic Solo</p>
        <select name="data" id="data" required="required">
            <option value="">--Please choose an option--</option>
            <option value="SMALL LoBM LoOP">SMALL LoBM LoOP</option>
            <option value="ME1 BM1 OP2">ME1 BM1 OP2</option>
            <option value="ME1 BM1 OP3">ME1 BM1 OP3</option>
            <option value="SMALL LoBM HiOP">SMALL LoBM HiOP</option>
            <option value="ME1 BM2 OP1">ME1 BM2 OP1</option>
            <option value="ME1 BM2 OP2">ME1 BM2 OP2</option>
        </select>
        <br>
        <label for="startRange">Start of the data range:</label>
        <input type="startRange" id="startRange" name="startRange" required="required">
        <label for="endRange">End of the data range:</label>
        <input type="endRange" id="endRange" name="endRange" required="required">
        <button class="submit" type="submit">Submit</button>
    </form>
    <form action="/graph3">
        <p>Line Graphic Duo</p>
        <select name="data" id="data" required="required">
            <option value="">--Please choose an option--</option>
            <option value="SMALL LoBM LoOP">SMALL LoBM LoOP</option>
            <option value="ME1 BM1 OP2">ME1 BM1 OP2</option>
            <option value="ME1 BM1 OP3">ME1 BM1 OP3</option>
            <option value="SMALL LoBM HiOP">SMALL LoBM HiOP</option>
            <option value="ME1 BM2 OP1">ME1 BM2 OP1</option>
            <option value="ME1 BM2 OP2">ME1 BM2 OP2</option>
        </select>
        <select name="secondData" id="secondData" required="required">
            <option value="">--Please choose an option--</option>
            <option value="SMALL LoBM LoOP">SMALL LoBM LoOP</option>
            <option value="ME1 BM1 OP2">ME1 BM1 OP2</option>
            <option value="ME1 BM1 OP3">ME1 BM1 OP3</option>
            <option value="SMALL LoBM HiOP">SMALL LoBM HiOP</option>
            <option value="ME1 BM2 OP1">ME1 BM2 OP1</option>
            <option value="ME1 BM2 OP2">ME1 BM2 OP2</option>
        </select>
        <label for="startRange">Start of the data range:</label>
        <input type="startRange" id="startRange" name="startRange" required="required">
        <label for="endRange">End of the data range:</label>
        <input type="endRange" id="endRange" name="endRange" required="required">
        <button class="submit" type="submit">Submit</button>
    </form>
    <form action="/graphBar">
        <p>Scatter Graphic </p>
        <select name="data" id="data" required="required">
            <option value="">--Please choose an option--</option>
            <option value="SMALL LoBM LoOP">SMALL LoBM LoOP</option>
            <option value="ME1 BM1 OP2">ME1 BM1 OP2</option>
            <option value="ME1 BM1 OP3">ME1 BM1 OP3</option>
            <option value="SMALL LoBM HiOP">SMALL LoBM HiOP</option>
            <option value="ME1 BM2 OP1">ME1 BM2 OP1</option>
            <option value="ME1 BM2 OP2">ME1 BM2 OP2</option>
        </select>
        <label for="startRange">Start of the data range:</label>
        <input type="startRange" id="startRange" name="startRange" required="required">
        <label for="endRange">End of the data range:</label>
        <input type="endRange" id="endRange" name="endRange" required="required">
        <button class="submit" type="submit">Submit</button>
    </form>
    <form action="/graphColumn">
        <p>Column Graphic</p>
        <select name="data" id="data" required="required">
            <option value="">--Please choose an option--</option>
            <option value="SMALL LoBM LoOP">SMALL LoBM LoOP</option>
            <option value="ME1 BM1 OP2">ME1 BM1 OP2</option>
            <option value="ME1 BM1 OP3">ME1 BM1 OP3</option>
            <option value="SMALL LoBM HiOP">SMALL LoBM HiOP</option>
            <option value="ME1 BM2 OP1">ME1 BM2 OP1</option>
            <option value="ME1 BM2 OP2">ME1 BM2 OP2</option>
        </select>
        <label for="startRange">Start of the data range:</label>
        <input type="startRange" id="startRange" name="startRange" required="required">
        <label for="endRange">End of the data range:</label>
        <input type="endRange" id="endRange" name="endRange" required="required">
        <button class="submit" type="submit">Submit</button>
    </form>


</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>