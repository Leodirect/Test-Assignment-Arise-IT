<?php $__env->startSection('contenu'); ?>
    <div id="ca_graph"></div>
    <?=$lava->render('LineChart','Stocks','ca_graph');?>
    <form action="/graph2">
        <select name="data" id="data">
            <option value="">--Please choose an option--</option>
            <option value="SMALL LoBM LoOP">SMALL LoBM LoOP</option>
            <option value="ME1 BM1 OP2">ME1 BM1 OP2</option>
            <option value="ME1 BM1 OP3">ME1 BM1 OP3</option>
            <option value="SMALL LoBM HiOP">SMALL LoBM HiOP</option>
            <option value="ME1 BM2 OP1">ME1 BM2 OP1</option>
            <option value="ME1 BM2 OP2">ME1 BM2 OP2</option>
        </select>
        <label for="startRange">Start of the data range:</label>
        <input type="startRange" id="startRange" name="startRange">
        <label for="endRange">End of the data range:</label>
        <input type="endRange" id="endRange" name="endRange">
        <button type="submit">Submit</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>