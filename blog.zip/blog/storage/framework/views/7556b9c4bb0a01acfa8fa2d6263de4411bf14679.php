<?php $__env->startSection('contenu'); ?>
<body>
<!-- Message -->
<?php if(Session::has('message')): ?>
    <p ><?php echo e(Session::get('message')); ?></p>
<?php endif; ?>

<!-- Form -->
<form method='post' action='/uploadFile' enctype='multipart/form-data' >
    <?php echo e(csrf_field()); ?>

    <input type='file' name='file' >
    <input type='submit' name='submit' value='Import'>

</form>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>